interface SearchHeaderProps {
    searchQuery: string;
    onSearchChange: (query: string) => void;
    onToggleAdvanced: () => void;
  }