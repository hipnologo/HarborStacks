import { LucideIcon } from "lucide-react";

export interface ServiceCategory {
  id: string;
  label: string;
  icon: LucideIcon;
}

export interface Service {
  id: string;
  name: string;
  description: string;
  category: string;
  popular?: boolean;
  requirements: string[]; // Updated from requiresConfig
  configSteps?: ConfigStep[]; 
  installSteps?: string[]; 
}

export interface ConfigStep {
  title: string
  description?: string
  fields: ConfigField[]
}

export interface ConfigField {
  name: string
  label: string
  type: 'text' | 'email' | 'password' | 'number'
  placeholder?: string
  required?: boolean
  validation?: {
    pattern?: string
    min?: number
    max?: number
    message?: string
  }
}

export interface InstallationConfig {
  [key: string]: string | number | boolean
}